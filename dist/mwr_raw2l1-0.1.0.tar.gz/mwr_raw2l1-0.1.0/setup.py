# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mwr_raw2l1',
 'mwr_raw2l1.measurement',
 'mwr_raw2l1.readers',
 'mwr_raw2l1.utils']

package_data = \
{'': ['*'],
 'mwr_raw2l1': ['config/*',
                'data/attex/orig/*',
                'data/radiometrics/orig/*',
                'data/rpg/0-20000-0-06610/*',
                'data/rpg/orig/*',
                'logs/*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0',
 'Sphinx>=4.3.2,<5.0.0',
 'colorlog>=4.2.1,<5.0.0',
 'dynaconf>=3.1.7,<4.0.0',
 'netCDF4>=1.5.6,<2.0.0',
 'scipy>=1.7.3,<2.0.0',
 'sphinx-rtd-theme>=1.0.0,<2.0.0',
 'sphinxcontrib-napoleon>=0.7,<0.8',
 'xarray>=0.20.1,<0.21.0']

entry_points = \
{'console_scripts': ['rpg_reader = mwr_raw2l1.reader_rpg:main']}

setup_kwargs = {
    'name': 'mwr-raw2l1',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'rruefenacht',
    'author_email': 'rruefenacht@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
